import RouterFiles from "./RouterFiles";

function App() {
  return (
    <div>
      <RouterFiles />
    </div>
  );
}

export default App;
